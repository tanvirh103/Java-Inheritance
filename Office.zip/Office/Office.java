public class Office{
	public static void main(String[]args){
		Staff s=new Staff();
		Officer o=new Officer();
	}
}