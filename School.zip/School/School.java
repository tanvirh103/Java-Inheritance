class School{
	public static void main(String[]args){
		
		Staff s=new Staff();
		Student st=new Student();
		Teacher t=new Teacher();
	}
}