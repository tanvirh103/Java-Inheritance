import java.util.*;
class Start{
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter your Number:");
		int a=sc.nextInt();
		System.out.println("Your Entered number is:"+a);
		
	}
}